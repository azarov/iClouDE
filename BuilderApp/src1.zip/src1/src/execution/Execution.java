package execution;
import java.nio.charset.Charset;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.*;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import ws.BuildServiceProperties;
import ws.HttpMultiClient;
import ws.TaskExecution;
import ws.TaskGetter;
import static ws.BuildServiceProperties.buildServiceProperties;

//TODO add ExecutionProperties


	private Logger logger = LogManager.getLogger(Execution.class.getName());
	
	public static void main(String[] args){
		ExecutorService executor = Executors.newFixedThreadPool(4);
		Timer timer = new Timer();
		final TaskGetter taskGetter = new TaskGetter(executor);
		timer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				taskGetter.run();
			}
		}, 0, 3000L);
		
		
	}
}
