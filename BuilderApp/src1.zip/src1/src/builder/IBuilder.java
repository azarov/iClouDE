package builder;

//import java.util.concurrent.Future;
import java.util.concurrent.RunnableFuture;

import entities.BuildResult;
import entities.Task;
/*
 * IBuilder: getTask + void build()
 * 
 * cancelling: can't be done from outside
 * done: determined by script
 * 
 */
public interface IBuilder{
	Task getTask();
	RunnableFuture<BuildResult> build();
}
