package builder.ant;

import java.io.File;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;

public class ScriptRunner {

	public static void main(String[] args) {
		
		Callable<Integer> c = new Callable<Integer>() {

			@Override
			public Integer call() throws Exception {
				File buildFile = new File("build.xml");
				Project p = new Project();
				p.setUserProperty("exec", "bash");
				p.setUserProperty("script", "script.sh");
				p.setUserProperty("args", "");
				
				DefaultLogger consoleLogger = new DefaultLogger();
				consoleLogger.setErrorPrintStream(System.err);
				consoleLogger.setOutputPrintStream(System.out);
				consoleLogger.setMessageOutputLevel(Project.MSG_INFO);
				p.addBuildListener(consoleLogger);
// script handles errors
				// we get what comes from error stream
				try {
					p.fireBuildStarted();
					p.init();
					ProjectHelper helper = ProjectHelper.getProjectHelper();
					p.addReference("ant.projectHelper", helper);
					helper.parse(p, buildFile);
					p.executeTarget("execscript");
					p.fireBuildFinished(null);
				} catch (BuildException e) {
					p.fireBuildFinished(e);
				}
				return 5;
			}
		};
		
		ExecutorService executor = Executors.newFixedThreadPool(4);
		FutureTask<Integer> f  = new FutureTask<Integer>(c);
		executor.execute(f);
		try {
			System.out.println(f.get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
