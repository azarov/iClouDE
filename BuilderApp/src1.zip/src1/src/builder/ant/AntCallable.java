package builder.ant;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DefaultLogger;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;

import entities.BuildResult;
import entities.BuildStatus;
import entities.Task;

import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

/*
 * TODO move to TaskProject class
 * project: src, bin, config, libs
 */
public class AntCallable implements Callable<BuildResult> {
	private Task task;
	private org.apache.tools.ant.Project p;
	private File buildLog;

	public AntCallable(Task task) {
		this.task = task;
		try {
			makeTaskFolder();
		} catch (IOException e) {
			e.printStackTrace();
		}
		p = antProject(new File("build.xml")); // -> to constants
		
		// Add build listener:
		buildLog = new File(getTaskFolder()+"/log");
		DefaultLogger consoleLogger = new DefaultLogger();
		// error message for WS will be generated separately 
		consoleLogger.setErrorPrintStream(System.err);
		try {
			consoleLogger.setOutputPrintStream(new PrintStream(buildLog));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		consoleLogger.setMessageOutputLevel(Project.MSG_INFO);
		p.addBuildListener(consoleLogger);

		p.setProperty("proj.dir", getTaskFolder().getAbsolutePath());
		// parse task: dir with sources, javac opts(libs)
		
		Properties props = parseTask();
		// task folder
		try {
			FileOutputStream out = new FileOutputStream(getTaskFolder()
					.getPath() + "/" + "task.properties");
			props.store(out, "--- task properties ---");
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void rm_rf(File dir) throws IOException {
		Path p = Paths.get(dir.toURI());
		Files.walkFileTree(p, new SimpleFileVisitor<Path>() {

			@Override
			public FileVisitResult visitFile(Path file,
					BasicFileAttributes attrs) throws IOException {
				Files.delete(file);
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult postVisitDirectory(Path dir, IOException exc)
					throws IOException {
				if (exc == null) {
					Files.delete(dir);
					return FileVisitResult.CONTINUE;
				} else {
					throw exc;
				}
			}

		});
	}

	private File makeTaskFolder() throws IOException {
		File result = getTaskFolder();
		if (result.exists()) {
			rm_rf(result);
		}
		result.mkdirs();
		return result;
	}

	/*
	 * all paths should be strings, probably properties file is needed
	 */
	private File getTaskFolder() {
		return new File(task.getId());
	}

	private File getBinFolder() {
		File dir = new File(getTaskFolder().getPath() + "/bin");
		if (!dir.exists()) {
			dir.mkdir();
		}
		return dir;
	}

	private File getSrcFolder() {
		File dir = new File(getTaskFolder().getPath() + "/src");
		if (!dir.exists()) {
			dir.mkdir();
		}

		return dir;
	}

	public Properties parseTask() {
		// TODO logging
		Properties props = new Properties();
		File srcDir = null;
		srcDir = getSrcFolder();
		unzip(srcDir);
		props.setProperty("src.dir", getSrcFolder().getAbsolutePath());
		props.setProperty("build.dir", getBinFolder().getAbsolutePath());
		// classpath, etc
		return props;
	}

	private void unzip(File outDir) {
		InputStream fis = null;
		try {
			fis = new FileInputStream(task.getFullPathToZip() + "");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ZipInputStream zis = new ZipInputStream(fis);
		byte[] buffer = new byte[4096];
		ZipEntry ze;
		try {
			while ((ze = zis.getNextEntry()) != null) {
				if (ze.isDirectory()) {
					new File(outDir.getPath() + "/" + ze.getName()).mkdir();
					continue;
				}
				FileOutputStream fos = new FileOutputStream(outDir.getPath()
						+ "/" + ze.getName());
				int numBytes;
				while ((numBytes = zis.read(buffer, 0, buffer.length)) != -1)
					fos.write(buffer, 0, numBytes);
				zis.closeEntry();
				fos.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public BuildResult call() {
		try {
			p.fireBuildStarted();
			p.executeTarget("compile.all");
		} catch (BuildException e) {
			p.fireBuildFinished(e);
			BuildResult r = new BuildResult(task.getId(), BuildStatus.FAILED, "BUILD FAILED");
			r.setLogs(buildLog.toURI());
			r.setCompiledSourcesPath(getBinFolder().toURI());
			return r;
		}

		BuildResult r = new BuildResult(task.getId(), BuildStatus.SUCCESSFUL, "BUILD SUCCESSFUL");
		r.setLogs(buildLog.toURI());
		r.setCompiledSourcesPath(getBinFolder().toURI()); 
		return r;
	}

	private Project antProject(File buildxml) {
		Project p = new Project();
		ProjectHelper helper = ProjectHelper.getProjectHelper();
		p.addReference("ant.projectHelper", helper);
		helper.parse(p, buildxml);
		p.init();
		return p;
	}

	// private void
}
