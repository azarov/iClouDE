package builder.ant;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;

import entities.BuildResult;
import entities.Task;
import builder.IBuilder;
import builder.common.BuilderAdapter;

/*
 * 
 */
public class AntBuilder extends BuilderAdapter implements IBuilder{

	public AntBuilder(Task task) {
		super(task);
	}

	@Override
	public Callable<BuildResult> newCallable() {
		return new AntCallable(getTask());
	}



}
