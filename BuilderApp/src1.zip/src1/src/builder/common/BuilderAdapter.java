package builder.common;

import java.util.concurrent.Callable;

import java.util.concurrent.FutureTask;
import java.util.concurrent.RunnableFuture;


import builder.IBuilder;

import entities.BuildResult;
import entities.Task;


/*	TODO
 * temporary class. Every builder should implement all Future methods itself.
 */
public abstract class BuilderAdapter implements IBuilder{
	private Task task;
	private FutureTask<BuildResult> inner;
	
	public BuilderAdapter(Task task){
		this.task = task;
		inner = new FutureTask<BuildResult>(newCallable());

	}
	
	public abstract Callable<BuildResult> newCallable();
	
	@Override
	public RunnableFuture<BuildResult> build(){
		Thread thread = new Thread(inner);
		thread.start();
		return inner;
		
	}
	
	@Override
	public Task getTask() {
		return task;
	}

}
