package ws;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.RunnableFuture;

import static ws.BuildServiceProperties.buildServiceProperties;

import com.google.gson.Gson;

import entities.BuildResult;

//TODO wrap RunnableFuture in some interface
public class TaskSender extends Thread {

	private RunnableFuture<BuildResult> buildProcess;

	public TaskSender(RunnableFuture<BuildResult> buildProcess) {
		this.buildProcess = buildProcess;
	}

	@Override
	public void run() {
		Gson gson = new Gson();
		BuildResult buildResult = null;
		try {
			buildResult = buildProcess.get();
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		String buildResultString = gson.toJson(buildResult, BuildResult.class);
		int statusCode = HttpMultiClient.INSTANCE
			.execPostRequest(buildResultString, "application/json", 
					buildServiceProperties().sendResultURI);

		System.out.println(statusCode);
		
	}
}
