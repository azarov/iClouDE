package ws;

import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.message.Message;

public class LoggingStuff {
	
	
	public static class BuildFailureMsg implements Message{

		@Override
		public String getFormat() {

			ThreadContext.put("", "");
			return null;
		}

		@Override
		public String getFormattedMessage() {
			return null;
		}

		@Override
		public Object[] getParameters() {
			return null;
		}
		
	}

}
