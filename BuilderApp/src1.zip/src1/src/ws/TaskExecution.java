package ws;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.util.concurrent.ExecutionException;

import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.protocol.*;
import org.apache.http.util.EntityUtils;

import builder.IBuilder;
import builder.ant.AntBuilder;

import com.google.gson.Gson;

import entities.BuildResult;
import entities.Task;
import static ws.BuildServiceProperties.buildServiceProperties;

/**
 * get task + solve task + post result
 */
public class TaskExecution extends Thread {

	private HttpClient httpClient;
	private HttpContext context;

	public TaskExecution(HttpClient httpClient) {
		this.httpClient = httpClient;
		this.context = new BasicHttpContext();
	}

	
	// get:URI, OutputStream -> InputStream
	//post:URI,InputStream -> void
	private Task getTask() {

		HttpGet httpGet = new HttpGet(buildServiceProperties().getTaskURI);
		// TODO TODO encoding!!
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			HttpResponse response = httpClient.execute(httpGet, context);
			HttpEntity entity = response.getEntity();
			

			if (entity != null) {
				entity.writeTo(baos);
			} 
		} catch (Exception e) {
			httpGet.abort();
			e.printStackTrace();
		}

		String taskS = new String(baos.toByteArray());
		Gson gson = new Gson();
		Task t = gson.fromJson(taskS, Task.class);
		return t;
	}

	@Override
	public void run() {
		Task task = getTask();
		if (task == null) {
			return;
		}

		System.out.println("got task successfully");
		IBuilder builder = new AntBuilder(task);
		BuildResult r = null;
		try {
			r = builder.build().get();
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		System.out.println("build finished");
		postBuildResult(r);
	}

	private void postBuildResult(BuildResult buildResult) {
		HttpPost httpPost = new HttpPost(buildServiceProperties().sendResultURI);
		Gson gson = new Gson();
		String s = gson.toJson(buildResult, BuildResult.class);
		InputStreamEntity reqEntity = new InputStreamEntity(
				new ByteArrayInputStream(s.getBytes()), -1);
		reqEntity.setContentType("application/json");
		httpPost.setEntity(reqEntity);
		HttpResponse response = null;
		try {
			response = httpClient.execute(httpPost);
		} catch (IOException e) {
			e.printStackTrace();
		}
		HttpEntity resEntity = response.getEntity();
		if (response.getStatusLine().getStatusCode() == 200) {
			System.out.println("task post ok");
		} else {
			System.out.println(response.getStatusLine());
		}
		try {
			if (resEntity != null) {
				EntityUtils.consume(resEntity);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}